/**
 * Created by xpeedstudio on 5/1/2018.
 */
jQuery(document).ready(function ($) {
    'use strict';

});