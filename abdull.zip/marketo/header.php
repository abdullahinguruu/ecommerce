<?php
/**
 * header.php
 *
 * The header for the theme.
 */
?>
<!DOCTYPE html>
 <html <?php language_attributes(); ?>>

    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<?php wp_head(); ?>
    </head>
	<?php

	$header_settings       = marketo_option('xs_header_builder_select');
	$header_builder_enable = marketo_option('header_builder_enable');

	if($header_builder_enable && class_exists('ElementsKit')){
		if(class_exists('\ElementsKit\Utils::render_elementor_content')){
			echo \ElementsKit\Utils::render_elementor_content($header_settings);
		}else{
			$elementor = \Elementor\Plugin::instance();
			echo \ElementsKit\Utils::render($elementor->frontend->get_builder_content_for_display( $header_settings));
		}
	}else{
		$header_layout = marketo_option( 'header_layout' );
		if ( $header_layout == 2 || $header_layout == 5 ) {
			$header_layout = 5;
		}
		get_header( $header_layout );
		get_template_part( 'template-parts/navigation/mobile', 'nav' );
	}
	$rtl	 = marketo_option( 'marketo_rtl' );
	$class[]  = '';
	if ( $rtl ) {
		$class[] = 'rtl';
	}
	global $yith_woocompare;
	?>
    <body <?php body_class( $class ); ?> data-spy="scroll" data-target="#header">
