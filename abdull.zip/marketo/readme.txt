/**
 * Theme Name: Marketo
 * Theme URI: http://www.xpeedstudio.com
 * Description: Marketo is powerful and modern multipurpose responsive WordPress Theme.
 * Version: 1.0
 * Author: XpeedStudio
 * Author URI: http://www.xpeedstudio.com
 * License: GNU General Public License version 3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 * Tags: one-column, two-columns, right-sidebar, left-sidebar, custom-menu, featured-images, post-formats, sticky-post, translation-ready
 * Text Domain: marketo;
 *
 * XS
 */
